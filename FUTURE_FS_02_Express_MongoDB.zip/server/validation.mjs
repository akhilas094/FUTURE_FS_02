import {z} from 'zod';
const date=z.string().refine(v=>!v||(/^\d{4}-\d{2}-\d{2}$/.test(v)&&!isNaN(Date.parse(v+'T12:00:00Z'))&&new Date(v+'T12:00:00Z').toISOString().slice(0,10)===v),'Enter a real follow-up date.');
export const leadSchema=z.object({name:z.string().trim().min(1).max(100),email:z.string().trim().toLowerCase().email().max(254),company:z.string().trim().max(150).default(''),phone:z.string().trim().max(40).default(''),source:z.enum(['Website','LinkedIn','Referral','Email','Other']).default('Website'),status:z.enum(['new','contacted','converted']).default('new'),followUp:date.default('')}).strict();
export const contactSchema=z.object({name:z.string().trim().min(1).max(100),email:z.string().trim().toLowerCase().email().max(254),company:z.string().trim().max(150).default(''),phone:z.string().trim().max(40).default(''),message:z.string().trim().min(1).max(4000),website:z.string().max(200).optional()}).strict();
export const loginSchema=z.object({email:z.string().trim().toLowerCase().email().max(254),password:z.string().min(1).max(200)}).strict();
export const noteSchema=z.object({leadId:z.string().uuid(),body:z.string().trim().min(1).max(4000)}).strict();
export const idSchema=z.string().uuid();
