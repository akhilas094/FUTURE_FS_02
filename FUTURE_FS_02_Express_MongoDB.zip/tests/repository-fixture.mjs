// Test-only fixture. Production always uses Mongoose and MongoStore.
export function testRepository(){const rows=new Map();return {
 async create(row){rows.set(row.id,structuredClone(row));return row},
 find(){return {sort(){return {async lean(){return [...rows.values()].map(row=>structuredClone(row)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))}}}}},
 async updateOne({id},change){const row=rows.get(id);if(!row)return {matchedCount:0};Object.assign(row,change.$set||{});if(change.$push?.notes)row.notes.push(structuredClone(change.$push.notes));return {matchedCount:1}},
 async deleteOne({id}){return {deletedCount:rows.delete(id)?1:0}}
}}
