// For a separately hosted portfolio, set this to your deployed Express endpoint.
window.LEADFLOW_CONTACT_ENDPOINT='/api/contact';
