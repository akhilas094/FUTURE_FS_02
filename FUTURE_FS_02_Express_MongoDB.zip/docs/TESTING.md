# Verification checklist

## Completed in the authoring environment

- React production build succeeds.
- TypeScript check succeeds.
- 25 API/validation test assertions pass using an isolated repository fixture.
- Tests cover unauthenticated API access, HttpOnly/SameSite cookies, CSRF token rotation, wrong credentials, origin rejection, public enquiry intake, message notes, honeypot, statuses, lead updates, dates, invalid IDs, note validation, deletion, conversion and logout.
- The earlier hosted edition was browser-tested for contact capture, notes, status updates, editing, follow-up scheduling, and persistence across reloads.

## Not yet verified

- Real MongoDB process startup and persistence in this environment: blocked by `Operation not permitted`.
- Full Express edition login/CRUD using a real MongoDB instance.
- New Express deployment, HTTPS secure cookies and environment configuration.
- Cross-origin submission from the user's separately hosted portfolio.
- Narrow-screen browser interaction (responsive CSS is implemented; complete the checks below).

## Manual acceptance checks after local setup

1. Visit the CRM while signed out; confirm no lead data is returned by `/api/leads`.
2. Sign in using your configured admin account. Confirm wrong passwords are rejected.
3. Submit a portfolio enquiry, then reload the dashboard. Confirm source Website and status New.
4. Open the lead and confirm its initial message was saved as a note.
5. Edit contact details, update New → Contacted → Converted, and reload.
6. Schedule a follow-up. Verify it appears in Follow-ups while not converted.
7. Add a note, reload, and verify it remains.
8. Search by name/email and filter status/source. Verify dashboard totals and export contents.
9. Delete a test lead using the confirmation prompt. Verify its notes disappear too.
10. Sign out and confirm the previous session can no longer read leads.
11. At 375px and 768px widths, check navigation, the add/edit form, status selection, drawer close, notes, and follow-up date input. Horizontal scrolling should be confined to the data table.
12. Test keyboard navigation, visible focus, form labels, and cancelling dialogs with Escape.
13. In production, verify HTTPS, HttpOnly/SameSite/Secure session cookies and allowed origin configuration.

Run `npm run test:integration` against a temporary database before final submission. Tests use synthetic contacts only.
